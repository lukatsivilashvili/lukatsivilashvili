import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.*;

public class MainController {

    @FXML
    public TextField secondM;

    @FXML
    public TextField firstN;

    @FXML
    public Label tvRandoms;

    @FXML
    public Button moda;

    @FXML
    public Button washla;

    @FXML
    public Label tvModa;

    ArrayList<Integer> randomsArrayList = new ArrayList<>();
    int[] randoms = new int[20];

    public void generateNumbers() {

        Random rand = new Random();
        int firstNumber = Integer.parseInt(firstN.getText());
        int secondNumber = Integer.parseInt(secondM.getText());

        if (firstNumber < secondNumber && firstNumber >= 3 && firstNumber <= 10 && secondNumber <= 10) {

            for (int i = 0; i < 19; i++) {
                int result = rand.ints(Integer.parseInt(firstN.getText()), Integer.parseInt(secondM.getText()))
                        .findFirst()
                        .getAsInt();
                randoms[i] = result;
                randomsArrayList.add(result);
            }
            tvRandoms.setText(Arrays.toString(randoms));
        } else {
            tvRandoms.setText("Numbers not in range");
        }

    }

    public void setModa(){
        int modaNumber = findMostFrequentElement(randoms);
        tvModa.setText("მოდაა: " + modaNumber);
    }

    public void removeEvens(){
        for (int i = 0; i < randomsArrayList.size(); i++) {
            if (randomsArrayList.get(i) %2 == 0){
                randomsArrayList.remove(i);
            }
        }
        tvRandoms.setText(randomsArrayList.toString());
        randomsArrayList.clear();
    }

    public static int findMostFrequentElement(int[] array) {
        // Create a map to store the frequency of each element
        Map<Integer, Integer> elementFrequency = new HashMap<>();

        // Iterate through the array and count the frequency of each element
        for (int element : array) {
            int frequency = elementFrequency.getOrDefault(element, 0) + 1;
            elementFrequency.put(element, frequency);
        }

        // Find the element with the highest frequency
        int mostFrequentElement = array[0];
        int highestFrequency = 0;
        for (Map.Entry<Integer, Integer> entry : elementFrequency.entrySet()) {
            if (entry.getValue() > highestFrequency) {
                mostFrequentElement = entry.getKey();
                highestFrequency = entry.getValue();
            }
        }

        return mostFrequentElement;
    }

}
